this mod for lost branch of legend adds mima to the game
made with love and unhingedness by lvalon
huge thanks to everyone in #modding of the official discord server for helping out and stuff~