this mod for lost branch of legend adds mima to the game

made with love and unhingedness by lvalon

wouldnt have made this without neo's sideloader: https://github.com/Neoshrimp/LBoL-Entity-Sideloader

intoxicated kid for providing LOTS of 9head code and sharing ideas: https://github.com/IntoxicatedKid

zosit for feedback and suggestions: https://github.com/Zosit

xeno for feedback: xeno_3084

raspberry caffeine monster for korean translation

also huge thanks to everyone in #modding of the official discord server for helping out and stuff~

and diddy for the OnRevive reactor suggestion: https://github.com/diddykong27

mima portrait/spellcard portrait by dairi: https://www.pixiv.net/en/users/4920496

mima sprite by hemogurobin a1c: https://www.pixiv.net/en/users/465582

status effect by walfas <3
