v0.0.26: reduce rare cards color intensiveness, dawn of time mana still gained fix, minor yaml fix

v0.0.25: mountain of pure diamonds adding to draw instead of discard, quik fix

v0.0.24: even more balancing #2, rip loops you will probably be missed

v0.0.23: mimaA gives magical burst on skill card use, not spell card, typo fix my bad

v0.0.22: increase changelog intuitiveness, card reference and value fix, add mimaA standard library cards and card gen fallback, minor balancing

v0.0.21: changelog line skip

v0.0.20: evil spirit once per turn visual update, typo & wording fix, more balancing bruh

v0.0.19: its rewind time missed accumulation effect, now fixed

v0.0.18: karmanation and evil spirit wording fix, they only affect attack damage

v0.0.17: even more balancing

v0.0.16: more balancing on discovery and generation cards

v0.0.15: some balancing

v0.0.14: made sure Rare cards cant be generated at the start of a mima gamerun

v0.0.12/v0.0.13: fix At The Dawn of Time 6color issue (lbol skill issue), and learnt that thunderstore upload and refresh is slow

v0.0.11: static image loading directory fixed

v0.0.1: early access mima public release