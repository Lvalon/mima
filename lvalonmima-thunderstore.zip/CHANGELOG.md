v0.0.33: dawn of time card art! also removes hand when that turn starting and card gen now actually ignores mana limit

v0.0.32: evil spirit & elixir compatibility fix, wraitsoth balance, dawn of time status effect reference fix, rewind time tooltip fix

v0.0.31: wraitsoth already doesn't give evil spirit, fixed yaml

v0.0.21-v0.0.30: changelog, mimaA starter cards, cards upgrades buff, ex temp firepower integration, starter cards are now common rarity, incrrease deck size, evil spirit opt limit, color tweaks, card rework, bugfix, balancing

v0.0.2-v0.0.20: img directory fix, 6color issue fix, bugfix, evil spirit once per turn visual update, balancing

v0.0.1: early access mima public release